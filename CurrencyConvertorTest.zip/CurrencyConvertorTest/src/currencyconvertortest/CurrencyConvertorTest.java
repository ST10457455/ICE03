package currencyconvertortest;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class CurrencyConvertorTest implements ActionListener {
    static final String API_ENDPOINT = "https://v6.exchangerate-api.com/v6/e17cb386654ebcb3cf0161fa/latest/USD";
    static String[] CURRENCIES = {
            "USD", "AED", "AFN", "ALL", "AMD", "ANG", "AOA", "ARS", "AUD", "AWG",
            "AZN", "BAM", "BBD", "BDT", "BGN", "BHD", "BIF", "BMD", "BND", "BOB",
            "BRL", "BSD", "BTN", "BWP", "BYN", "BZD", "CAD", "CDF", "CHF", "CLP",
            "CNY", "COP", "CRC", "CUP", "CVE", "CZK", "DJF", "DKK", "DOP", "DZD",
            "EGP", "ERN", "ETB", "EUR", "FJD", "FKP", "FOK", "GBP", "GEL", "GGP",
            "GHS", "GIP", "GMD", "GNF", "GTQ", "GYD", "HKD", "HNL", "HRK", "HTG",
            "HUF", "IDR", "ILS", "IMP", "INR", "IQD", "IRR", "ISK", "JEP", "JMD",
            "JOD", "JPY", "KES", "KGS", "KHR", "KID", "KMF", "KRW", "KWD", "KYD",
            "KZT", "LAK", "LBP", "LKR", "LRD", "LSL", "LYD", "MAD", "MDL", "MGA",
            "MKD", "MMK", "MNT", "MOP", "MRU", "MUR", "MVR", "MWK", "MXN", "MYR",
            "MZN", "NAD", "NGN", "NIO", "NOK", "NPR", "NZD", "OMR", "PAB", "PEN",
            "PGK", "PHP", "PKR", "PLN", "PYG", "QAR", "RON", "RSD", "RUB", "RWF",
            "SAR", "SBD", "SCR", "SDG", "SEK", "SGD", "SHP", "SLL", "SOS", "SRD",
            "SSP", "STN", "SYP", "SZL", "THB", "TJS", "TMT", "TND", "TOP", "TRY",
            "TTD", "TVD", "TWD", "TZS", "UAH", "UGX", "UYU", "UZS", "VEF", "VND",
            "VUV", "WST", "XAF", "XCD", "XDR", "XOF", "XPF", "YER", "ZAR", "ZMW",
            "ZWL"
    };

    static UserManager userManager = new UserManager();
    static User currentUser;

    static JFrame f;
    static JLabel amountLabel;
    static JLabel fromLabel;
    static JLabel toLabel;
    static JLabel resultLabel;
    static JComboBox<String> fromCurrencyBox;
    static JComboBox<String> toCurrencyBox;
    static JTextField AmountField;
    static JPanel p;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // User authentication in the console
        while (currentUser == null) {
            System.out.print("1. Login\n2. Register\nChoose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            if (choice == 1) {
                System.out.print("Username: ");
                String username = scanner.nextLine();
                System.out.print("Password: ");
                String password = scanner.nextLine();
                currentUser = userManager.loginUser(username, password);
                if (currentUser == null) {
                    System.out.println("Invalid credentials.");
                }
            } else if (choice == 2) {
                System.out.print("Choose a username: ");
                String username = scanner.nextLine();
                System.out.print("Choose a password: ");
                String password = scanner.nextLine();
                if (userManager.registerUser(username, password)) {
                    System.out.println("Registration successful. Please log in.");
                } else {
                    System.out.println("Username already taken.");
                }
            }
        }

        // Choose between console or GUI mode
        System.out.print("Choose mode:\n1. Console\n2. GUI\nEnter your choice: ");
        int mode = scanner.nextInt();
        scanner.nextLine(); // consume newline

        if (mode == 1) {
            runConsoleMode(scanner);
        } else if (mode == 2) {
            runGUIMode();
        }
    }

    public static void runConsoleMode(Scanner scanner) {
        System.out.println("Available Currencies:");
        for (int i = 0; i < CURRENCIES.length; i++) {
            System.out.print(CURRENCIES[i] + " ");
            if ((i + 1) % 10 == 0) {
                System.out.println();
            }
        }
        System.out.println("\n");

        System.out.print("Enter amount to convert: ");
        double amount = scanner.nextDouble();

        System.out.print("Enter currency to convert from (e.g., USD): ");
        String fromCurrency = scanner.next().toUpperCase();

        System.out.print("Enter currency to convert to (e.g., EUR): ");
        String toCurrency = scanner.next().toUpperCase();

        try {
            double result = convert(amount, fromCurrency, toCurrency);
            System.out.printf("%.2f %s = %.2f %s%n", amount, fromCurrency, result, toCurrency);

            // Save conversion history
            String conversion = String.format("%.2f %s = %.2f %s", amount, fromCurrency, result, toCurrency);
            currentUser.addConversionHistory(conversion);
            userManager.saveUsers();

            // Add to favorite pairs
            String pair = fromCurrency + " to " + toCurrency;
            if (!currentUser.getFavoritePairs().contains(pair)) {
                currentUser.addFavoritePair(pair);
            }
            userManager.saveUsers();

        } catch (IOException e) {
            System.err.println("Error while converting: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.err.println("Invalid currency code: " + e.getMessage());
        }
    }

    public static void runGUIMode() {
        f = new JFrame("CURENCIO");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setSize(300, 350);
        f.setLayout(null);
        f.setLocationRelativeTo(null);

        amountLabel = new JLabel("Amount");
        amountLabel.setFont(new Font("Arial", Font.BOLD, 16));
        amountLabel.setBounds(15, 10, 100, 34);

        AmountField = new JTextField("1");
        AmountField.setBounds(10, 40, 180, 34);

        fromLabel = new JLabel("From");
        fromLabel.setFont(new Font("Arial", Font.BOLD, 16));
        fromLabel.setBounds(15, 70, 80, 34);

        toLabel = new JLabel("To");
        toLabel.setFont(new Font("Arial", Font.BOLD, 16));
        toLabel.setBounds(15, 130, 80, 34);

        fromCurrencyBox = new JComboBox<>(CURRENCIES);
        fromCurrencyBox.setBounds(5, 105, 200, 25);

        toCurrencyBox = new JComboBox<>(CURRENCIES);
        toCurrencyBox.setBounds(5, 165, 200, 25);

        resultLabel = new JLabel();

        p = new JPanel();
        p.setLocation(300, 150);

        JButton converterButton = new JButton("Convert");
        converterButton.setFont(new Font("Arial", Font.BOLD, 16));
        converterButton.setBackground(Color.RED);
        converterButton.setBounds(10, 220, 280, 40);
        f.add(amountLabel);
        f.add(AmountField);
        f.add(fromLabel);
        f.add(toLabel);
        f.add(fromCurrencyBox);
        f.add(toCurrencyBox);
        f.add(converterButton);
        converterButton.addActionListener(new CurrencyConvertorTest());
        f.add(p);
        f.setVisible(true);
    }

    @SuppressWarnings("deprecation")
    public static double convert(double amount, String fromCurrency, String toCurrency) throws IOException {
        // Make Request
        URL url = new URL(API_ENDPOINT);
        HttpURLConnection request = (HttpURLConnection) url.openConnection();
        request.connect();

        JsonElement root = JsonParser.parseReader(new InputStreamReader(request.getInputStream()));
        JsonObject rates = root.getAsJsonObject().get("conversion_rates").getAsJsonObject();

        if (!rates.has(fromCurrency) || !rates.has(toCurrency)) {
            throw new IllegalArgumentException("Invalid currency code.");
        }

        double fromRate = rates.get(fromCurrency).getAsDouble();
        double toRate = rates.get(toCurrency).getAsDouble();

        return amount * (toRate / fromRate);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            String amount = AmountField.getText();
            String fromCurrency = fromCurrencyBox.getSelectedItem().toString();
            String toCurrency = toCurrencyBox.getSelectedItem().toString();

            double result = convert(Double.parseDouble(amount), fromCurrency, toCurrency);
            resultLabel.setText(String.valueOf(result));
            resultLabel.setBounds(45, 270, 280, 20);
            resultLabel.setForeground(Color.BLACK);
            resultLabel.setFont(new Font("Arial", Font.BOLD, 16));
            f.add(resultLabel);
            f.revalidate();
            f.repaint();
            
            

            // Save conversion history
            String conversion = String.format("%.2f %s = %.2f %s", Double.parseDouble(amount), fromCurrency, result, toCurrency);
            currentUser.addConversionHistory(conversion);
            userManager.saveUsers();

            // Add to favorite pairs
            String pair = fromCurrency + " to " + toCurrency;
            if (!currentUser.getFavoritePairs().contains(pair)) {
                currentUser.addFavoritePair(pair);
            }
            userManager.saveUsers();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Invalid input or error in conversion: " + ex.getMessage());
        }
    }
}

class User {
    private String username;
    private String password;
    private List<String> favoritePairs;
    private List<String> conversionHistory;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
        this.favoritePairs = new ArrayList<>();
        this.conversionHistory = new ArrayList<>();
    }

    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public List<String> getFavoritePairs() { return favoritePairs; }
    public void addFavoritePair(String pair) { favoritePairs.add(pair); }
    public List<String> getConversionHistory() { return conversionHistory; }
    public void addConversionHistory(String history) { conversionHistory.add(history); }
}

class UserManager {
    private Map<String, User> users = new HashMap<>();

    public UserManager() {
        loadUsers();
    }

    public boolean registerUser(String username, String password) {
        if (users.containsKey(username)) {
            return false;
        }
        users.put(username, new User(username, password));
        saveUsers();
        return true;
    }

    public User loginUser(String username, String password) {
        User user = users.get(username);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }

    public void saveUsers() {
        try (FileWriter writer = new FileWriter("users.json")) {
            Gson gson = new Gson();
            gson.toJson(users, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadUsers() {
        try (FileReader reader = new FileReader("users.json")) {
            Gson gson = new Gson();
            Type type = new TypeToken<HashMap<String, User>>() {}.getType();
            users = gson.fromJson(reader, type);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
